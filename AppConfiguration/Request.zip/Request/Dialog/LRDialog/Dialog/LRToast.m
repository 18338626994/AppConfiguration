//
//  LRToast.m
//  AppConfiguration
//
//  Created by 汇来米-iOS于云飞 on 2020/7/10.
//  Copyright © 2020 PnR. All rights reserved.
//

#import "LRToast.h"

@implementation LRToast

- (LRToast *)backgroundOpacity:(double)opacity {
    return self;
}

@end
